# Disneyland Paris

Summary: Amusement Park in Paris, Disney themed
Rating: Not yet rated
When?: Planned
City: Paris
Country: France
Date: 14/12/2026 → 20/12/2026
Person: Bella, Charles, Charlotte, Hanna
Price: €1000,-

## Notes

---

- Voor de 55ste verjaardag van Fernanda!