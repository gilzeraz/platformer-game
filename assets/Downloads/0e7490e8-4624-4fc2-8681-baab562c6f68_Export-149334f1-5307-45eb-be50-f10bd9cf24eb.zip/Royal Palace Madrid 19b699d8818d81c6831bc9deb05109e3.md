# Royal Palace Madrid

When?: At some point
City: Madrid
Country: Spain
Price: Free