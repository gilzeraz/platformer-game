# Stockholm

When?: At some point
City: Stockholm
Country: Sweden